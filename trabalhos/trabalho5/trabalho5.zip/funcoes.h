#ifndef FUNCOES_H
#define FUNCOES_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{

  float item1, item2, item3, item4;
  char *o;
}itens;

typedef struct{
    int id;
    float saque, deposito, transferencia_entrou, transferencia_saiu;
}banco;

typedef struct{
    float lucro;
    itens **operacoes;
    int qnt_operacoes;
    banco **bancos;
    int qnt_bancos, *id_bancos;
}terminal;

typedef struct{
  banco *i_bancos;
  int qnt;
}banco_final;

/**
 * [separa_itens description]
 * @param  entradas   [description]
 * @param  quantidade [description]
 * @return            [description]
 */
itens **separa_itens(char **entradas, int quantidade);

/**
 * [processa_entrada description]
 * @param  entradas [description]
 * @return          [description]
 */
terminal **processa_entrada(itens **entradas, int qnt);
/**
 * [analiza_dado description]
 * @param  dado [description]
 * @return      [description]
 */

/**
 * [passa_para_terminal description]
 * @param operacao [description]
 * @param t        [description]
 */
void passa_para_terminal(itens *operacao, terminal *t);



int analiza_dado(itens *dado);


int hash(int terminal, int banco);

/**
 * [novo_espaco description]
 * @return [description]
 */
banco *novo_espaco();

/**
 * [salva_nova_operacao_banco description]
 * @param operacao [description]
 * @param b        [description]
 */
int salva_nova_operacao_banco(itens *operacao, banco *b);

/**
 * [relatorio description]
 * @param t [description]
 */
void relatorio(terminal **t);
void mostra_info_banco(banco *b);
void salva_final(banco_final *bf, banco *salvar);
void transferencia_bancos(itens *operacao, banco *recebe);
void libera_entrada(int qnt, char **dados);
void libera_itens(int qnt, itens **item);
#endif
